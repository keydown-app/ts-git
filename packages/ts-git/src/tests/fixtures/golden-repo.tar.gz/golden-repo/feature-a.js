Feature A implementation
Feature A refinements
