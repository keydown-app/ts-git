Nested helper
