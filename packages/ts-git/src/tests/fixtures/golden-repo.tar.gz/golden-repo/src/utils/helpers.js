Utility functions
More updates
